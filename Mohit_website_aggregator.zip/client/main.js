//Please go through Readme.md file.. Have given full description over there about what things I have done in this project.

///--->>> collection name is Websites
/// add account-ui account-password twbs:bootstrap iron:router	
//// meteor add acemtp:meta-extractor for meta data extraction/ auto website info getter :) :) :) 
//// meteor add arkham:comments-ui -- for comments work
/////meteor add easy:search -- for search work
///// suggestions done using regular expressions...
/////Finally done every part of the peer assessment including the challenges... :) :) :) :)  Top Recommendation uses REGEX with a new collection called "TopRecommend"... Cool Stuff!!! :)
//----login configuration---//
  Accounts.ui.config({passwordSignupFields:"USERNAME_AND_EMAIL"});


	//////////
	//Easy:Search
	Template.searchBox.helpers({
  websitesIndex: () => WebsitesIndex
	});
	//Easy:Search
	//////////

	/////////////////////
	//comments work starts 
	/////////	

	// On the Client
Comments.ui.config({
   template: 'bootstrap' // or ionic, semantic-ui
});
	//////
	//comments work ends
	/////////////////////	



	/////////////////////
	//router starts 
	/////////	

///--->>>Layout<<<----\\\

Router.configure({
layoutTemplate:'ApplicationLayout',
});


///--->>>Index Page<<<----\\\

Router.route('/',function(){

this.render('welcome');
});	
	
	
///--->>>List Page<<<----\\\

Router.route('/lists',function(){

this.render('searchButton',{to:'back'});
this.render('recommendations',{to:'recommendations'});
this.render('list_form',{to:'main'});
this.render('navbar',{to:'navbar'});
});


///--->>>Detail page<<<----\\\

Router.route('/details/:_id',function(){
this.render('myComments',{to:'comments'});
this.render('comment_box',{to:'commentbox',
data:function(){
var result;
var user=Websites.findOne({'_id':this.params._id});
//console.log("value is"+Websites.findOne({'_id':this.params._id}));
return user;
}
});
this.render('back_to_lists',{to:'back'});
this.render('navbar',{to:'navbar'});
this.render('website_item',{
to:'main',
data:function(){
var result;
var user=Websites.findOne({'_id':this.params._id});


//console.log("value is"+Websites.findOne({'_id':this.params._id}));
return user;
},
});
});


///--->>>searchWebsites Page<<<----\\\

Router.route('/searchWebsites',function(){

this.render('back_to_lists',{to:'back'});
this.render('searchBox',{to:'main'});
});	



	//////
	//router ends
	/////////////////	



	///////////////////////////////
	// TEMPLATE helpers <<<<<<<<<<<<
	/////

///////////	
///top recommendation helper function

	Template.recommendations.helpers({
websites:function(){
var lastVoted=TopRecommend.findOne({_id:Meteor.user()._id}).lastVoted;
console.log(lastVoted);
var title=Websites.findOne({'_id':lastVoted}).title;
console.log(title);
var tsplit=title.split(" ");
var regex="";//creating regular expression...
console.log(tsplit);
for(var i=0;i<tsplit.length;i++)
{
regex=regex+".*"+tsplit[i]+".*";
if(i!=tsplit.length-1)
regex+="|";
}
console.log(regex);

return Websites.find({$or:[{"title" : {$regex : regex,$options:'i'}},
{"description":{$regex : regex,$options:'i'}}]});
},
UserSignedIn:function()
			{
				if(Meteor.user()) return true;
				else return false;	
			},

});

/////top Recommendation ends here---- ;) 
//////////

// helper function that returns all available websites
	Template.website_list.helpers({
		websites:function(){
		/*return Websites.find({$or:[{"title" : {$regex : ".*YOUNG.*|.*google.*",$options:'i'}},
{"description":{$regex : ".*access.*|.*universal.*",$options:'i'}}]});*/
//<--how to give suggestions-- ;)			
//Websites.createIndex( { title: "text" } );
			return Websites.find({},{sort:{upvotes:-1,downvotes:1},});
		}
	});
	//---->>>> Helper function that returns whether current user is signed in or not... ;)
	Template.website_form.helpers({
		UserSignedIn:function()
			{
				if(Meteor.user()) return true;
				else return false;	
			}
	});
		
	Template.website_item.helpers({
		UserSignedIn:function()
			{
				if(Meteor.user()) return true;
				else return false;	
			}
	});

	Template.comment_box.helpers({
		UserSignedIn:function()
			{
				if(Meteor.user()) return true;
				else return false;	
			}
	});


	/////
	// template helpers 
	////////////////////////////

	////////////
	// template events 
	/////

	Template.website_item.events({
		"click .js-upvote":function(event){
			// example of how you can access the id for the website in the database
			// (this is the data context for the template)
			var website_id = this._id;
			console.log("Up voting website with id "+website_id);
			// put the code in here to add a vote to a website!
			Websites.update({_id:website_id},{$set:{upvotes:(this.upvotes+1)}});
			lastVoted=website_id;
			//Meteor.users.update({_id:Meteor.user()._id},{$set:{profile.lastVoted:(website_id)}});//<<<--lastVoted
			

			//coding for recommendations
		if(TopRecommend.findOne({_id:Meteor.user()._id}))
{
//update
TopRecommend.update({_id:Meteor.user()._id},{$set:{lastVoted:lastVoted}});
}
else
{
//insert
TopRecommend.insert({_id:Meteor.user()._id,lastVoted:lastVoted});
}
		return false;// prevent the button from reloading the page	
		}, 
		"click .js-downvote":function(event){

			// example of how you can access the id for the website in the database
			// (this is the data context for the template)
			var website_id = this._id;
			console.log("Down voting website with id "+website_id);

			// put the code in here to remove a vote from a website!
			
			Websites.update({_id:website_id},{$set:{downvotes:(this.downvotes+1)}});
			return false;// prevent the button from reloading the page
		}
	})

	Template.website_form.events({
		"click .js-toggle-website-form":function(event){
			$("#website_form").toggle('slow');
		}, 
		"submit .js-save-website-form":function(event){

			// here is an example of how to get the url out of the form:
			var url = event.target.url.value;
			if(!url)
			return false;
			console.log("The url they entered is: "+url);
			var title;
			if(event.target.title.value)
			title=event.target.title.value;
			else//suppose no title is given by the user. Also if no title found then we can show this url in title.
			title=url;
			var desc;
			if(event.target.description.value)
			desc=event.target.description.value;
			else//suppose no desc is given by the user. Also if no desc found then we can show this comment below.
			desc="No description available...";		
			var createdOn=new Date();//getting date
			var createdBy=Meteor.userId();//getting user id
			//console.log(createdBy+" "+desc+" "+title);
			//  put your website saving code in here!
			////////------>>>>>>>
			//----Meta data finder---
			/////////////<<<<<<-----
			if(url)	
			extractMeta(url, function (err, res) {
			console.log("error present"+err);  
			console.log('objec'+Object.values(res)[1]);	
			if(res.description)
			desc=res.description; 
			if(res.title)
			title=res.title;	
			console.log('objecterer'+res+" "+title +desc);
			
			var check=Websites.findOne({url:url});
			if(check)
			alert(url+"  Website has been already added -- :( So now Insertion done!!!");
			else{				
			Websites.insert({url:url,title:title,description:desc,createdOn:createdOn,createdBy:createdBy,upvotes:0,downvotes:0});
			alert(url+"  Website has been added -- :)");
			}				
			});	
			////////------>>>>>>>
			//----Meta data finder ends---
			/////////////<<<<<<-----
		
		
			return false;// stop the form submit from reloading the page

		}
	});

